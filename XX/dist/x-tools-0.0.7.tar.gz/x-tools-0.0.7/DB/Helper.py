#!/usr/bin/python3
# -*- coding:utf-8 -*-
# @Time       : 2018/9/10 22:54
# @Author    : Bill Steve
# @Email      : billsteve@126.com
# @File         : Help.py
# @Software : PyCharm


# 根据json生成sql
def getSqlByDict(d, tb_name="tb_name", tb_comment="COMMENT"):
    s = "\n\nCREATE TABLE `{tb_name}` (\n`id` int(11) NOT NULL AUTO_INCREMENT,\n\n".format(tb_name=tb_name)
    for k, v in d.items():
        if type(v) in [int, float]:
            s += """\t`{key}` int(11) DEFAULT NULL,""".format(key=k if str(k) != "id" else "web_id") + "\n"
        elif type(v) == list:
            s += """\t`{key}` longtext DEFAULT NULL,""".format(key=k if str(k) != "id" else "web_id") + "\n"
        elif type(v) == dict:
            if v.get("id"):
                s += """\t`{key}_web_id`  varchar(255) DEFAULT NULL,""".format(key=k) + "\n"
                print(":WebWebWebWebWeb")
            else:
                s += """\t`{key}` longtext DEFAULT NULL,""".format(key=k if str(k) != "id" else "web_id") + "\n"
        else:
            s += """\t`{key}` varchar(255) DEFAULT NULL,""".format(key=k if str(k) != "id" else "web_id") + "\n"
    s += """
        `is_del` int(11) DEFAULT 0,
        `create_ts` int(11) DEFAULT NULL,
        `update_ts` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='{tb_comment}';""".format(tb_comment=tb_comment)
    print(s)


def getCreateTableSqlBySqlDump(fp):
    for line in open(fp, "r", encoding="utf-8"):
        if line.find("INSERT") >= 0 or line.find("--") >= 0 or line.find("/*") >= 0:
            continue
        print(line.strip())


def delRedisKeysByPrefix(prefix, conn):
    for key in conn.keys():
        if str(key).startswith(prefix):
            conn.delete(key)
            print(key)


if __name__ == '__main__':
    d ={'dpShopId': 93510444, 'shopName': '湊湊火锅·茶憩(国际广场店)', 'defaultPicUrl': 'https://img.meituan.net/msmerchant/c5a66f178ebd257428498f04b79f38b11734735.jpg%40180w_180h_1e_1c_1l%7Cwatermark%3D0', 'shopPower': 45, 'avgPrice': 145, 'mainCategoryName': '小火锅', 'regionName': '武汉广场', 'distance': 1067066, 'distanceStr': '1067.0km', 'queueWaitCount': 0, 'queueStateDesc': '', 'shopUrl': 'https://h5.dianping.com/app/menuorder-queue-h5/queue.html?dpShopId=93510444&appId=wxf1080b96abe5d72c&openId=oSVwytxFsePRmODGw86yr4fjQMng&src=1'}

    getSqlByDict(d)
