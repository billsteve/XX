# # -*- encoding:utf8 -*-

# 代理数量
PROXY_NUM = 5
# 是否是测试环境
TEST = 0
MASTER = 1
# 代理超限的时候 单进程暂停时间
TS_429 = 1

# 代理信息
PROXY_UN = "HF60345RM388C8ZD"
PROXY_PWD = "F583670DE9072F1E"

# 核对爬虫天数
CHECK_DAYS = 10

HEADERS = {
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "zh-CN,zh;q=0.5",
    "Cache-Control": "max-age=0",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36",
}

headers_12315 = {
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Content-Length": "53",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Host": "www.12315.cn",
    "Origin": "http://www.12315.cn",
    "Referer": "http://www.12315.cn/corperation/index",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.26 Safari/537.36 Core/1.63.4467.400 QQBrowser/10.0.424.400",
    "X-Requested-With": "XMLHttpRequest",
}

WORDS16 = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f"]

HOST_LOCAL = "localhost"
HOST_UBUNTU = "192.168.1.42"
HOST_QQ = "119.29.208.231"
HOST_ZHIAHN_WEB = "39.104.57.130"
HOST_ZHIAHN_MYSQL = "39.104.97.69"
HOST_MOMO_ALI = "39.106.115.211"

MYSQL_HOST_ALI = "rm-2zepyov257k1r521vwo.mysql.rds.aliyuncs.com"
MYSQL_HOST_QQ = "cd-cdb-f41yw26m.sql.tencentcdb.com"
MYSQL_USER = "cartip"
MYSQL_PWD = "rebind1234"
MYSQL_PORT = 3306
MYSQL_CHARSET = "utf8"

MYSQL_USER_UBUNTU = "root"
MYSQL_PWD_UBUNTU = "rebind1234"
MYSQL_PORT_UBUNTU = 3306
MYSQL_CHARSET_UBUNTU = "utf8"

REDIS_PORT = 6379
REDIS_PWD = 0

MONGO_PORT = 27017

MYSQL_URL_ZHIHAN = MYSQL_USER + ":" + MYSQL_PWD + "@" + HOST_ZHIAHN_MYSQL + ":" + str(3366)
MYSQL_URL_ZHIHAN_LOCAL = "root" + ":" + MYSQL_PWD + "@" + HOST_UBUNTU + ":" + str(3306)

PWD_ALL = "DRsXT5ZJ6Oi55LPQ"
