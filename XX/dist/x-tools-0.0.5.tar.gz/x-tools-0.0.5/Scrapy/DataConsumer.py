#!/usr/bin/python3
# -*- coding:utf-8 -*-
# @Time       : 2018/12/2 16:26
# @Author    : Bill Steve
# @Email      : billsteve@126.com
# @File         : DataCustomer.py
# @Des         :
# @Software : PyCharm
import importlib
import json
import time

import Utils.DB.SqlAlchemyHelper as sa
import Utils.DB.RedisHelper as udr
import Utils.Tools.BuiltinFunctions as bf
import Utils.Threading.AsyncHelper as ah


class IDataCustomer:

    def customer(self, **kw):
        pass


class MQ2DB(IDataCustomer):

    def customer(self, **kw):
        pass

    @staticmethod
    def redis2mysql(*arg, **kw):
        pass

    @staticmethod
    def save2db(json_data, spider, mcfg):
        module = importlib.import_module("SpiderJson2DB")
        func = getattr(module, spider)
        if func:
            return func(json_data, mcfg, spider)
        else:
            print("No " + str(spider) + "'s  save 2 db")


class Redis2Mysql(MQ2DB):

    # 初始化redis和MySQL连接类
    def __init__(self, **kw):
        self.conn_redis = udr.RedisHelper.getRedisConnectByCfg(kw.get("rcfg"))
        self.conn_mysql = sa.SqlAlchemyHelper.getMysqlSessionByCfg(kw.get("mcfg"))

    # def customer(self, **kw):
    #     self.redis2mysql(**kw)

    @ah.async_call
    def redis2mysql(self, **kw):
        while 1:
            spider = kw.get("spider")
            json_str = self.conn_redis.lpop(spider + ":items")
            if kw.get("debug"):
                # 放回
                self.conn_redis.lpush(spider + ":items", json_str)
            if json_str:
                json_data = json.loads(json_str, encoding="utf-8")
                func = kw.get("func")
                # func(json_data, kw.get("mcfg"))
                func(json_data, self.conn_mysql)
            else:
                bf.printNoEnd(spider + "\tNo more item")
                time.sleep(kw.get("ts", 5))
                if kw.get("once"):
                    print("One circle over")
                    break


#
def redis2mysql(**kw):
    conn_redis = udr.RedisHelper.getRedisConnectByCfg(kw.get("rcfg"))
    conn_mysql = sa.SqlAlchemyHelper.getMysqlSessionByCfg(kw.get("mcfg"))
    while 1:
        spider = kw.get("spider")
        json_str = conn_redis.rpop(spider + ":items")
        if kw.get("debug"):
            # 放回
            print("+++>>> Readd=====")
            conn_redis.lpush(spider + ":items", json_str)
        if json_str:
            json_data = json.loads(json_str, encoding="utf-8")
            func = kw.get("func")
            func(json_data, conn_mysql)
            conn_mysql.commit()
        else:
            # bf.printFromHead(spider + "\tNo more item")
            bf.printFromHead(spider + "\tNo more item \t")
            time.sleep(kw.get("ts", 5))
            if kw.get("once"):
                print("One circle over")
                break
