#!/usr/bin/python3
# -*- coding:utf-8 -*-
# @Time       : 2019/1/3 22:04
# @Author    : Bill Steve
# @Email      : billsteve@126.com
# @File         : setup.py
# @Des         : 
# @Software : PyCharm
from setuptools import setup, find_packages

setup(
    name="x-tools",
    version="0.0.5",
    description=(
        "x's tools"
    ),
    long_description="""**Just Test** 
    > Not safe and not stable""",
    author='x',
    author_email='billsteve@126.com',
    maintainer='myself',
    maintainer_email='billsteve@126.com',
    license='MIT License',
    packages=find_packages(),
    platforms=["all"],
    url='https://github.com/billsteve',

    install_requires=[
        'Twisted>=19.2.0',
        'lxml',
        "scrapy",
        "scrapyd",
        "scrapyd-client",
        "scrapy-redis",
        "pyquery",
        "redis",
        "requests",
        "pymysql",
        "pymongo",
        "newspaper3k",
        "sqlalchemy",
        "logzero",
        "happybase",
    ],
    classifiers=[
        'Programming Language :: Python :: 3.6',
        'Topic :: Software Development :: Libraries'
    ],
)