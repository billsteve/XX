#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time     : 2018/9/20 10:02
# @Author   : Peter
# @Des       : 
# @File        : Callback
# @Software: PyCharm


def msg(msg, *arg, **kw):
    print("---" * 60)
    print("callback -------> {}".format(msg))
    print("---" * 60)


if __name__ == "__main__":
    pass
