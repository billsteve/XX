#!/usr/bin/python3
# -*- coding:utf-8 -*-
# @Time       : 2018/8/19 17:12
# @Author    : Bill Steve
# @Email      : billsteve@126.com
# @File         : Decorator.py
# @Software : PyCharm

if __name__ == '__main__':
    pass
