# coding: utf-8
from sqlalchemy import Column, Index, Integer, text
from sqlalchemy.dialects.mysql import TEXT, VARCHAR
from sqlalchemy.ext.declarative import declarative_base
from Utils.Model.SqlAlchemy.BaseModel import *

Base = declarative_base()
metadata = Base.metadata


class ComChangelog(Base, BaseModel):
    __tablename__ = 'com_changelog'

    id = Column(Integer, primary_key=True)
    com_id = Column(Integer)
    web_key = Column(VARCHAR(255))
    ProjectName = Column(TEXT)
    ChangeDate = Column(VARCHAR(255))
    BeforeContent = Column(TEXT)
    AfterContent = Column(TEXT)
    is_del = Column(VARCHAR(255))
    create_ts = Column(VARCHAR(255))
    update_ts = Column(VARCHAR(255))


class ComEmployee(Base, BaseModel):
    __tablename__ = 'com_employees'

    id = Column(Integer, primary_key=True)
    com_id = Column(Integer)
    web_key = Column(VARCHAR(255))
    Name = Column(VARCHAR(255))
    Job = Column(VARCHAR(255))
    CerNo = Column(VARCHAR(255))
    ScertName = Column(VARCHAR(255))
    is_del = Column(Integer)
    update_ts = Column(Integer)
    create_ts = Column(Integer)


class ComHolder(Base, BaseModel):
    __tablename__ = 'com_holder'

    id = Column(Integer, primary_key=True)
    com_id = Column(Integer)
    invested_id = Column(VARCHAR(60))
    web_key = Column(VARCHAR(255))
    StockName = Column(VARCHAR(255))
    StockType = Column(VARCHAR(255))
    StockPercent = Column(VARCHAR(255))
    IdentifyType = Column(VARCHAR(255))
    IdentifyNo = Column(VARCHAR(255))
    ShouldCapi = Column(VARCHAR(255))
    ShoudDate = Column(VARCHAR(255))
    InvestType = Column(VARCHAR(255))
    InvestName = Column(VARCHAR(255))
    RealCapi = Column(VARCHAR(255))
    CapiDate = Column(VARCHAR(255))
    Org = Column(VARCHAR(255))
    HolderRate = Column(VARCHAR(10))
    is_del = Column(Integer)
    update_ts = Column(Integer)
    create_ts = Column(Integer)


class ComInfo(Base, BaseModel):
    __tablename__ = 'com_info'

    id = Column(Integer, primary_key=True)
    com_id = Column(Integer, index=True)
    web_key = Column(VARCHAR(255))
    logo = Column(VARCHAR(255))
    name = Column(VARCHAR(255))
    tel = Column(VARCHAR(255))
    email = Column(VARCHAR(255))
    web_url = Column(VARCHAR(255))
    Address = Column(VARCHAR(255))
    AnnualReports = Column(VARCHAR(255))
    CreditCode = Column(VARCHAR(255))
    taxpayer_no = Column(VARCHAR(255))
    No = Column(VARCHAR(255))
    organization_no = Column(VARCHAR(255), server_default=text("''"))
    OperName = Column(VARCHAR(255))
    RegistCapi = Column(VARCHAR(255))
    Status = Column(VARCHAR(255))
    StartDate = Column(VARCHAR(255))
    EconKind = Column(VARCHAR(255))
    staff_num = Column(VARCHAR(255))
    TermStart = Column(VARCHAR(255))
    TeamEnd = Column(VARCHAR(255))
    BelongOrg = Column(VARCHAR(255))
    CheckDate = Column(VARCHAR(255))
    en_name = Column(VARCHAR(255))
    register_addr = Column(VARCHAR(255))
    industry_belong = Column(VARCHAR(255))
    used_name = Column(VARCHAR(255))
    location = Column(VARCHAR(255))
    Scope = Column(TEXT)
    intro = Column(TEXT)
    EndDate = Column(VARCHAR(255))
    Province = Column(VARCHAR(50))
    Industry = Column(VARCHAR(255))
    ImageUrl = Column(VARCHAR(255))
    OrgNo = Column(VARCHAR(255))
    EnglishName = Column(VARCHAR(255))
    Type = Column(VARCHAR(255))
    Tag = Column(VARCHAR(255))
    Financing = Column(VARCHAR(255))
    id_del = Column(VARCHAR(255))
    create_ts = Column(Integer)
    update_ts = Column(Integer)

    def __init__(self, *arg, **kw):
        self.Address = kw.get("Address", None)
        self.AnnualReports = kw.get("AnnualReports", None)
        self.BelongOrg = kw.get("BelongOrg", None)
        self.CheckDate = kw.get("CheckDate", None)
        self.CreditCode = kw.get("CreditCode", None)
        self.EconKind = kw.get("EconKind", None)
        self.EndDate = kw.get("EndDate", None)
        self.EnglishName = kw.get("EnglishName", None)
        self.Financing = kw.get("Financing", None)
        self.ImageUrl = kw.get("ImageUrl", None)
        self.Industry = kw.get("Industry", None)
        self.No = kw.get("No", None)
        self.OperName = kw.get("OperName", None)
        self.OrgNo = kw.get("OrgNo", None)
        self.Province = kw.get("Province", None)
        self.RegistCapi = kw.get("RegistCapi", None)
        self.Scope = kw.get("Scope", None)
        self.StartDate = kw.get("StartDate", None)
        self.Status = kw.get("Status", None)
        self.Tag = kw.get("Tag", None)
        self.TeamEnd = kw.get("TeamEnd", None)
        self.TermStart = kw.get("TermStart", None)
        self.Type = kw.get("Type", None)
        self.com_id = kw.get("com_id", None)
        self.web_key = kw.get("web_key", None)
        self.create_ts = kw.get("create_ts", None)
        self.email = kw.get("email", None)
        self.en_name = kw.get("en_name", None)
        self.get = kw.get("get", None)
        self.getAll = kw.get("getAll", None)
        self.getAllIds = kw.get("getAllIds", None)
        self.getByFromId = kw.get("getByFromId", None)
        self.getByFromIdAndMod = kw.get("getByFromIdAndMod", None)
        self.getByName = kw.get("getByName", None)
        self.id = kw.get("id", None)
        self.id_del = kw.get("id_del", None)
        self.industry_belong = kw.get("industry_belong", None)
        self.intro = kw.get("intro", None)
        self.location = kw.get("location", None)
        self.logo = kw.get("logo", None)
        self.metadata = kw.get("metadata", None)
        self.name = kw.get("name", None)
        self.organization_no = kw.get("organization_no", None)
        self.register_addr = kw.get("register_addr", None)
        self.staff_num = kw.get("staff_num", None)
        self.taxpayer_no = kw.get("taxpayer_no", None)
        self.tel = kw.get("tel", None)
        self.update_ts = kw.get("update_ts", None)
        self.used_name = kw.get("used_name", None)
        self.web_url = kw.get("web_url", None)

    @staticmethod
    def getByComId(com_id, session):
        return session.query(ComInfo).filter(ComInfo.com_id == com_id).limit(1).all()

    @staticmethod
    def getByComKey(web_key, session):
        return session.query(ComInfo).filter(ComInfo.web_key == web_key).limit(1).all()

    @staticmethod
    def saveComInfo(data, session):
        com_id = data["com_id"]
        if com_id:
            exists = ComInfo.getByComId(com_id, session)
            if not exists:
                com_info = ComInfo(**data)
                ComInfo.addModel(com_info, session)
                return com_info.id
            else:
                return exists[0].id


class ComInvest(Base, BaseModel):
    __tablename__ = 'com_invest'
    __table_args__ = (
        Index('wy', 'com_id', 'invest_id', unique=True),
    )

    id = Column(Integer, primary_key=True)
    com_id = Column(Integer)
    invest_id = Column(Integer)
    invest_ts = Column(Integer)
    create_ts = Column(Integer)
    update_ts = Column(Integer)


class ComKey500(Base, BaseModel):
    __tablename__ = 'web_key_500'

    id = Column(Integer, primary_key=True)
    web_key = Column(VARCHAR(65), unique=True)
    has_crawled = Column(Integer)
    firm = Column(VARCHAR(255))
    invest = Column(VARCHAR(255))
    my_id = Column(Integer)
    create_ts = Column(Integer)
    update_ts = Column(Integer)

    @staticmethod
    def getByComKey(web_key, session):
        return session.query(ComInfo).filter(ComInfo.web_key == web_key).limit(1).all()


class ComKey(Base, BaseModel):
    __tablename__ = 'com_keys'

    id = Column(Integer, primary_key=True)
    com_name = Column(VARCHAR(200))
    short_name = Column(VARCHAR(100))
    web_id = Column(Integer)
    web_url = Column(VARCHAR(100))
    web_key = Column(VARCHAR(100), unique=True)
    cassets = Column(Integer)
    cinvestment = Column(Integer)
    cjob = Column(Integer)
    clawsuit = Column(Integer)
    creport = Column(Integer)
    crun = Column(Integer)
    firm = Column(Integer)
    info = Column(VARCHAR(40))
    is_del = Column(Integer)
    level = Column(Integer)
    create_ts = Column(Integer)
    update_ts = Column(Integer)

    def __init__(self, *arg, **kw):
        self.cassets = kw.get("cassets", None)
        self.cinvestment = kw.get("cinvestment", None)
        self.cjob = kw.get("cjob", None)
        self.clawsuit = kw.get("clawsuit", None)
        self.com_name = kw.get("com_name", None)
        self.create_ts = kw.get("create_ts", None)
        self.creport = kw.get("creport", None)
        self.crun = kw.get("crun", None)
        self.firm = kw.get("firm", None)
        self.get = kw.get("get", None)
        self.getAll = kw.get("getAll", None)
        self.getAllIds = kw.get("getAllIds", None)
        self.getByFromId = kw.get("getByFromId", None)
        self.getByFromIdAndMod = kw.get("getByFromIdAndMod", None)
        self.getByName = kw.get("getByName", None)
        self.id = kw.get("id", None)
        self.info = kw.get("info", None)
        self.is_del = kw.get("is_del", None)
        self.level = kw.get("level", None)
        self.metadata = kw.get("metadata", None)
        self.short_name = kw.get("short_name", None)
        self.update_ts = kw.get("update_ts", None)
        self.web_key = kw.get("web_key", None)
        self.web_url = kw.get("web_url", None)
        self.web_id = kw.get("web_id", None)

    @staticmethod
    def saveComKey(data, session):
        web_key = data["web_key"]
        if web_key:
            exists = ComKey.getByKV("web_key", web_key, session)
            if not exists:
                web_key = ComKey(**data)
                ComKey.addModel(web_key, session)
                return web_key.id
            else:
                return exists[0].id

    @staticmethod
    def saveComKeyAndComInfo(data, session):
        com_id = ComKey.saveComKey(data, session)
        if com_id:
            data["com_id"] = com_id
            add_info = ComInfo.saveComInfo(data, session)
            if add_info:
                return 1


class ComSub(Base, BaseModel):
    __tablename__ = 'com_sub'

    id = Column(Integer, primary_key=True)
    com_id = Column(Integer)
    web_key = Column(VARCHAR(255))
    subcom_id = Column(Integer)
    subweb_key = Column(VARCHAR(255))
    is_del = Column(Integer)
    create_ts = Column(Integer)
    update_ts = Column(Integer)


if __name__ == '__main__':
    createInitFunction(ComSub)
