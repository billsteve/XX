#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time     : 2018/11/27 13:51
# @Author   : Bill
# @Email      : billsteve@126.com
# @Des       : 
# @File        : KafkaConn
# @Software: PyCharm

