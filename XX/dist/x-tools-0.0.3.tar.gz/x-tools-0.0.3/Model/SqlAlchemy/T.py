# coding: utf-8
from sqlalchemy import Column, Index, String, TIMESTAMP, Text, text
from sqlalchemy.dialects.mysql import BIGINT, INTEGER, LONGTEXT, TINYINT
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
metadata = Base.metadata



class QqmuiscAlbum(Base):
    __tablename__ = 'qqmuisc_album'

    id = Column(BIGINT(20), primary_key=True)
    web_id = Column(String(40), nullable=False, unique=True)
    name = Column(String(200), server_default=text("''"))
    picture_url = Column(String(400), server_default=text("''"))
    pic_str = Column(String(200), server_default=text("''"))
    pic = Column(String(200))
    release_date = Column(String(20), server_default=text("''"))
    artist_web_ids = Column(String(200), server_default=text("''"))
    artist_names = Column(String(255))
    share_num = Column(BIGINT(40))
    comment_num = Column(BIGINT(40))
    play_num = Column(BIGINT(40))
    collect_num = Column(BIGINT(40))
    intro = Column(LONGTEXT)
    music_web_mids = Column(Text)
    status = Column(INTEGER(11), server_default=text("'0'"))
    createtime = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))

class QqmusicPlayinfo(Base):
    __tablename__ = 'qqmusic_playinfo'
    __table_args__ = (
        Index('web_id', 'web_id', 'term', unique=True),
    )

    id = Column(INTEGER(11), primary_key=True)
    web_id = Column(BIGINT(20))
    term = Column(String(20))
    listenCount = Column(BIGINT(40))
    topTitle = Column(String(255), server_default=text("''"))
    type = Column(String(255))
    status = Column(String(255))
    createtime = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class QqmusicPlaylist(Base):
    __tablename__ = 'qqmusic_playlist'
    __table_args__ = (
        Index('wy', 'url', 'term', 'rank', unique=True),
    )

    id = Column(BIGINT(20), primary_key=True)
    name = Column(String(200), nullable=False)
    url = Column(String(191), nullable=False, index=True)
    artist_web_mids = Column(String(255))
    artist_web_ids = Column(String(255), nullable=False)
    artist_names = Column(String(255))
    album_web_id = Column(INTEGER(10), nullable=False)
    album_web_mid = Column(String(40), server_default=text("''"))
    term = Column(String(20), index=True, server_default=text("''"))
    rank = Column(INTEGER(11), index=True)
    is_only = Column(TINYINT(1), server_default=text("'0'"))
    pay_info = Column(Text)
    status = Column(INTEGER(11), nullable=False, server_default=text("'0'"))
    createtime = Column(TIMESTAMP, nullable=False, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class QqmusicSong(Base):
    __tablename__ = 'qqmusic_song'

    id = Column(INTEGER(11), primary_key=True)
    web_id = Column(BIGINT(20))
    web_mid = Column(String(40), unique=True)
    star = Column(BIGINT(20))
    bullet_num = Column(BIGINT(40))
    status = Column(TINYINT(4))
    createtime = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))


class SougoumusicPlaylist(Base):
    __tablename__ = 'sougoumusic_playlist'

    id = Column(INTEGER(11), primary_key=True)
    pay_type_320 = Column(INTEGER(11))
    m4afilesize = Column(INTEGER(11))
    price_sq = Column(INTEGER(11))
    filesize = Column(INTEGER(11))
    bitrate = Column(INTEGER(11))
    trans_param = Column(LONGTEXT)
    price = Column(INTEGER(11))
    inlist = Column(INTEGER(11))
    old_cpy = Column(INTEGER(11))
    pkg_price_sq = Column(INTEGER(11))
    pay_type = Column(INTEGER(11))
    topic_url = Column(String(255))
    rp_type = Column(String(255))
    pkg_price = Column(INTEGER(11))
    feetype = Column(INTEGER(11))
    filename = Column(String(255))
    price_320 = Column(INTEGER(11))
    extname = Column(String(255))
    hash = Column(String(255))
    audio_id = Column(INTEGER(11))
    privilege = Column(INTEGER(11))
    _320hash = Column('320hash', String(255))
    album_audio_id = Column(INTEGER(11))
    topic_url_320 = Column(String(255))
    brief = Column(String(255))
    fail_process_sq = Column(INTEGER(11))
    fail_process_320 = Column(INTEGER(11))
    _320filesize = Column('320filesize', INTEGER(11))
    rp_publish = Column(INTEGER(11))
    has_accompany = Column(INTEGER(11))
    topic_url_sq = Column(String(255))
    sqfilesize = Column(INTEGER(11))
    remark = Column(String(255))
    duration = Column(INTEGER(11))
    _320privilege = Column('320privilege', INTEGER(11))
    sqhash = Column(String(255))
    fail_process = Column(INTEGER(11))
    pkg_price_320 = Column(INTEGER(11))
    pay_type_sq = Column(INTEGER(11))
    mvhash = Column(String(255))
    sqprivilege = Column(INTEGER(11))
    cover = Column(String(255))
    album_id = Column(String(255))
    is_del = Column(INTEGER(11), server_default=text("'0'"))
    create_ts = Column(INTEGER(11))
    update_ts = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"))
